# Local Pump-01 simulator controls used by the authenticated operator view.
import binascii
from java.lang import ProcessBuilder, String
from java.io import File
from java.nio.file import Files
from java.net import InetSocketAddress, Socket
from java.util.concurrent import TimeUnit
from java.util.concurrent.locks import ReentrantLock

PYTHON = r"C:\Users\IDSAID-VICTUS\AppData\Local\Programs\Python\Python312\python.exe"
SIMULATOR = r"C:\Users\IDSAID-VICTUS\Desktop\IIot-Predictive-Maintenance-Platform\simulator\simulator.py"
_STATE = system.util.getGlobals().setdefault(
    "iiot.pump01.local_control.v1", {"lock": ReentrantLock(), "process": None})
_RUNNER = """
import asyncio
import importlib.util
import json
import sys
import paho.mqtt.client as mqtt

spec = importlib.util.spec_from_file_location("pump_simulator", sys.argv[1])
sim = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sim)

class LocalServer(sim.Server):
    def set_endpoint(self, url):
        return super().set_endpoint(url.replace("0.0.0.0", "127.0.0.1"))

sim.Server = LocalServer
mqtt_client = mqtt.Client(
    mqtt.CallbackAPIVersion.VERSION2, client_id="ignition-pump01-simulator")
mqtt_client.connect_async("127.0.0.1", 1883, 60)
mqtt_client.loop_start()

def publish_readings(timestamp, elapsed_s, mode, fault_type, values):
    # Match the existing Node-RED/InfluxDB schema without exposing the hidden fault.
    payload = {
        "asset": sim.MACHINE_ID,
        "timestamp": timestamp,
        "measurements": {
            "temperature": values["temperature"],
            "vibration": values["vibration"],
            "current": values["current"],
            "mode": mode,
        },
    }
    mqtt_client.publish("factory/pump01/state", json.dumps(payload), qos=0, retain=False)

sim.append_ground_truth = publish_readings
try:
    asyncio.run(sim.run_opcua_server())
finally:
    mqtt_client.disconnect()
    mqtt_client.loop_stop()
"""


def _alive():
    process = _STATE.get("process")
    return process is not None and process.isAlive()


def _port_in_use():
    socket = Socket()
    try:
        socket.connect(InetSocketAddress("127.0.0.1", 4840), 250)
        return True
    except:
        return False
    finally:
        socket.close()


def _record(detail, actor):
    def insert(tx):
        PumpStationMonitor._event(
            tx, system.date.toMillis(system.date.now()), "Operator", detail, actor)
    PumpStationMonitor._mutate(insert)


def status():
    _STATE["lock"].lock()
    try:
        reading = system.tag.readBlocking(["[default]IIoT/Pump01/Mode"], 1000)[0]
        if _alive():
            return "Running" if reading.quality.isGood() else "Starting"
        if reading.quality.isGood():
            return "External simulator online"
        process = _STATE.get("process")
        if process is not None and process.exitValue() != 0:
            return "Start failed"
        return "Stopped"
    finally:
        _STATE["lock"].unlock()


def _stop():
    process = _STATE.get("process")
    if process is not None and process.isAlive():
        process.destroy()
        if not process.waitFor(3, TimeUnit.SECONDS):
            process.destroyForcibly()
            if not process.waitFor(3, TimeUnit.SECONDS):
                raise RuntimeError("Pump-01 simulator did not stop")
    _STATE["process"] = None
    error_file = _STATE.pop("error_file", None)
    if error_file is not None:
        error_file.delete()


def command(action, actor):
    if not actor:
        return "Sign in to control Pump-01."
    if action not in ("start", "stop", "restart"):
        raise ValueError("Unknown pump command")
    _STATE["lock"].lock()
    try:
        if action == "stop":
            if not _alive():
                return ("Stop the external simulator at its source." if _port_in_use()
                        else "Pump-01 is already stopped.")
            _stop()
            _record("Pump-01 simulator stopped by operator", actor)
            return "Pump-01 stopped."
        if action == "start" and _alive():
            return "Pump-01 is already running."
        if action == "restart" and _alive():
            _stop()
            _record("Pump-01 simulator stopped for restart", actor)
        if _port_in_use():
            return "Another simulator is using Pump-01. Stop it at its source first."
        # Record intent before launching so a database outage cannot leave an unaudited command.
        _record("Pump-01 simulator %s requested" % action, actor)
        _stop()
        # Keep Python source intact through Windows command-line quoting.
        encoded_runner = binascii.hexlify(_RUNNER.encode("utf-8"))
        bootstrap = "exec(bytes.fromhex('%s'))" % encoded_runner
        builder = ProcessBuilder([PYTHON, "-B", "-u", "-c", bootstrap, SIMULATOR])
        builder.redirectOutput(ProcessBuilder.Redirect.DISCARD)
        error_file = File.createTempFile("pump01-control-", ".log")
        error_file.deleteOnExit()
        builder.redirectError(error_file)
        _STATE["error_file"] = error_file
        process = builder.start()
        _STATE["process"] = process
        if process.waitFor(1, TimeUnit.SECONDS):
            detail = String(Files.readAllBytes(error_file.toPath()), "UTF-8")
            system.util.getLogger("PumpStationControl").error(str(detail))
            return "Simulator could not start (exit %s). Check Gateway diagnostics." % process.exitValue()
        _record("Pump-01 simulator %s accepted" % action, actor)
        return "Pump-01 %s. Four-minute cycle begins at Normal." % (
            "restarting" if action == "restart" else "starting")
    finally:
        _STATE["lock"].unlock()

