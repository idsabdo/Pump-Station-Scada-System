# Gateway-side station state and maintenance workflow.
from java.util.concurrent.locks import ReentrantLock

DATABASE = "Sample_SQLite_Database"
MODE_TAG = "[default]IIoT/Pump01/Mode"
TASKS = {
    "balance": "Check impeller balance",
    "bearing": "Inspect bearing",
    "alignment": "Verify alignment",
}
PHASES = {
    "normal": "Normal",
    "degrading": "Degrading",
    "fault_imminent": "Fault imminent",
}
LOCK = ReentrantLock()
initialized = False
previous = None


def _initialize():
    global initialized
    if initialized:
        return
    statements = (
        """CREATE TABLE IF NOT EXISTS iiot_ps_state (
             id INTEGER PRIMARY KEY CHECK (id = 1), phase TEXT NOT NULL,
             workflow TEXT NOT NULL, episode INTEGER NOT NULL)""",
        """CREATE TABLE IF NOT EXISTS iiot_ps_events (
             id INTEGER PRIMARY KEY, at_ms INTEGER NOT NULL,
             category TEXT NOT NULL, detail TEXT NOT NULL, actor TEXT NOT NULL)""",
        """CREATE TABLE IF NOT EXISTS iiot_ps_orders (
             id INTEGER PRIMARY KEY, task TEXT NOT NULL, origin TEXT NOT NULL,
             actor TEXT NOT NULL, created_ms INTEGER NOT NULL, status TEXT NOT NULL,
             closed_ms INTEGER, closed_by TEXT, notes TEXT, auto_episode INTEGER UNIQUE)""",
        """INSERT OR IGNORE INTO iiot_ps_state (id, phase, workflow, episode)
           VALUES (1, 'offline', 'Manual', 0)""",
    )
    for statement in statements:
        system.db.runUpdateQuery(statement, DATABASE)
    initialized = True


def _mutate(action):
    LOCK.lock()
    try:
        _initialize()
        tx = system.db.beginTransaction(DATABASE, system.db.SERIALIZABLE, 5000)
        try:
            result = action(tx)
            system.db.commitTransaction(tx)
            return result
        except:
            system.db.rollbackTransaction(tx)
            raise
        finally:
            system.db.closeTransaction(tx)
    finally:
        LOCK.unlock()


def _read(statement):
    LOCK.lock()
    try:
        _initialize()
        return system.db.runPrepQuery(statement, [], DATABASE)
    finally:
        LOCK.unlock()


def _event(tx, now, category, detail, actor):
    system.db.runPrepUpdate(
        "INSERT INTO iiot_ps_events (at_ms, category, detail, actor) VALUES (?, ?, ?, ?)",
        [now, category, detail, actor], DATABASE, tx)


def _create_order(tx, task, actor, now, episode=None):
    origin = "Automatic" if episode is not None else "Manual"
    order_id = system.db.runPrepUpdate(
        """INSERT INTO iiot_ps_orders (task, origin, actor, created_ms, status, auto_episode)
           VALUES (?, ?, ?, ?, 'Open', ?)""",
        [task, origin, actor, now, episode], DATABASE, tx, 1)
    identifier = "WO-%03d" % order_id
    _event(tx, now, "Maintenance", "%s created - %s" % (identifier, task), actor)
    return identifier


def _ensure_auto_order(tx, now, episode):
    found = system.db.runPrepQuery(
        "SELECT id FROM iiot_ps_orders WHERE auto_episode = ?", [episode], DATABASE, tx)
    if not found.getRowCount():
        _create_order(tx, "Inspect Pump-01 following a fault-imminent condition",
                      "Gateway", now, episode)


def tick():
    global previous
    reading = system.tag.readBlocking([MODE_TAG], 1500)[0]
    phase = str(reading.value).strip().lower() if reading.quality.isGood() else "offline"
    if phase not in PHASES:
        phase = "offline"
    if phase == previous:
        return

    def update(tx):
        state = system.db.runPrepQuery(
            "SELECT phase, workflow, episode FROM iiot_ps_state WHERE id = 1", [], DATABASE, tx)[0]
        old_phase, workflow, episode = str(state[0]), str(state[1]), int(state[2])
        if phase == old_phase:
            return
        now = system.date.toMillis(system.date.now())
        if old_phase == "offline":
            _event(tx, now, "Communications", "Pump-01 telemetry online", "Gateway")
        if phase == "offline":
            _event(tx, now, "Communications", "Pump-01 telemetry unavailable", "Gateway")
        else:
            _event(tx, now, "Equipment", "Pump-01 entered %s phase" % PHASES[phase], "Gateway")
        if phase == "fault_imminent":
            episode += 1
            if workflow == "Automatic":
                _ensure_auto_order(tx, now, episode)
        system.db.runPrepUpdate(
            "UPDATE iiot_ps_state SET phase = ?, episode = ? WHERE id = 1",
            [phase, episode], DATABASE, tx)
    _mutate(update)
    previous = phase


def get_mode():
    return str(_read("SELECT workflow FROM iiot_ps_state WHERE id = 1")[0][0])


def set_mode(mode, actor):
    if mode not in ("Manual", "Automatic"):
        raise ValueError("Unknown workflow mode")

    def update(tx):
        state = system.db.runPrepQuery(
            "SELECT phase, workflow, episode FROM iiot_ps_state WHERE id = 1", [], DATABASE, tx)[0]
        if mode == str(state[1]):
            return "Workflow is already %s." % mode
        now = system.date.toMillis(system.date.now())
        system.db.runPrepUpdate("UPDATE iiot_ps_state SET workflow = ? WHERE id = 1",
                                [mode], DATABASE, tx)
        _event(tx, now, "Operator", "Maintenance workflow changed to %s" % mode, actor)
        if mode == "Automatic" and str(state[0]) == "fault_imminent":
            _ensure_auto_order(tx, now, int(state[2]))
        return "Workflow set to %s." % mode
    return _mutate(update)


def create(task, actor):
    if task not in TASKS:
        return "Select a maintenance task."

    def update(tx):
        return "%s created." % _create_order(tx, TASKS[task], actor,
                                            system.date.toMillis(system.date.now()))
    return _mutate(update)


def complete(identifier, notes, actor):
    identifier = str(identifier or "").strip().upper()
    notes = unicode(notes or "").strip()
    if not identifier.startswith("WO-") or not identifier[3:].isdigit() or len(identifier) > 14:
        return "Enter a valid work order ID."
    if not notes:
        return "Enter the inspection result before completing the order."
    if len(notes) > 500:
        return "Keep the inspection result within 500 characters."

    def update(tx):
        now = system.date.toMillis(system.date.now())
        count = system.db.runPrepUpdate(
            """UPDATE iiot_ps_orders SET status = 'Complete', closed_ms = ?, closed_by = ?, notes = ?
               WHERE id = ? AND status = 'Open'""",
            [now, actor, notes, int(identifier[3:])], DATABASE, tx)
        if count != 1:
            return "No open work order matches that ID."
        _event(tx, now, "Maintenance", "%s completed" % identifier, actor)
        return "%s completed." % identifier
    return _mutate(update)


def _time(value):
    if value is None:
        return ""
    return system.date.format(system.date.fromMillis(long(value)), "yyyy-MM-dd HH:mm:ss")


def work_orders():
    rows = _read("""SELECT id, task, status, origin, created_ms, actor, closed_ms, closed_by, notes
                    FROM iiot_ps_orders ORDER BY id DESC LIMIT 250""")
    return [{"id": "WO-%03d" % row[0], "task": row[1], "status": row[2], "origin": row[3],
             "opened": _time(row[4]), "operator": row[5], "closed": _time(row[6]),
             "completedBy": row[7] or "", "notes": row[8] or ""} for row in rows]


def events():
    rows = _read("""SELECT at_ms, category, detail, actor
                    FROM iiot_ps_events ORDER BY id DESC LIMIT 250""")
    return [{"time": _time(row[0]), "category": row[1], "event": row[2], "actor": row[3]}
            for row in rows]
